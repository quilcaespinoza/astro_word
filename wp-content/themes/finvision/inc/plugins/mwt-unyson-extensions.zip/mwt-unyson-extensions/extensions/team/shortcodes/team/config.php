<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Team', 'mwt-unyson-extensions' ),
		'description' => esc_html__( 'Team various views', 'mwt-unyson-extensions' ),
		'tab'         => esc_html__( 'Widgets', 'mwt-unyson-extensions' )
	)
);