jQuery('#fw-backend-option-fw-option-team_icon').closest('.postbox').addClass('team-icon-postbox');
